# PowerShell Script to Sync/Import leads from the Excel File
$resolvedPath = Get-ChildItem -Path "C:\Users\admin\Downloads" -Filter "*leads fanpage.xlsx" | Select-Object -ExpandProperty FullName
if (-not $resolvedPath) {
    Write-Error "Could not find any file matching '*leads fanpage.xlsx' in Downloads!"
    exit 1
}
Write-Output "Syncing Excel File: $resolvedPath"

# Functions for mapping (using accent-insensitive safe regex matching)
function Get-SalesId($cskh) {
    if (-not $cskh) { return "usr-admin" }
    $cskhClean = $cskh.ToLower().Trim()
    if ($cskhClean -match "minh" -and $cskhClean -match "phuong") { return "usr-3" }
    if ($cskhClean -match "m.phuong") { return "usr-3" }
    if ($cskhClean -match "bich" -and $cskhClean -match "phuong") { return "usr-7" }
    if ($cskhClean -match "phuong") { return "usr-7" }
    if ($cskhClean -match "trang") { return "usr-6" }
    if ($cskhClean -match "tu" -and $cskhClean -match "anh") { return "usr-2" }
    return "usr-admin"
}

function Get-Source($sourceText) {
    if (-not $sourceText) { return "Fanpage" }
    $src = $sourceText.ToLower().Trim()
    if ($src -match "page" -or $src -match "fanpage") { return "Fanpage" }
    if ($src -match "cu") { return "KH cu" }
    if ($src -match "bni") { return "BNI" }
    if ($src -match "gt") { return "GT" }
    if ($src -match "nhan") { return "Ca nhan" }
    if ($src -match "gioi" -or $src -match "thieu" -or $src -match "dong" -or $src -match "cong") { return "Gioi thieu" }
    return "Fanpage"
}

function Get-Stage($statusText) {
    if (-not $statusText) { return "receive_info" }
    $st = $statusText.ToLower().Trim()
    if ($st -match "cham" -or $st -match "soc") { return "get_phone" }
    if ($st -match "thanh" -or $st -match "cong") { return "success" }
    if ($st -match "khong" -or $st -match "quan" -or $st -match "tam") { return "failed" }
    return "receive_info"
}

function Convert-ExcelDate($val) {
    if (-not $val) { 
        return (Get-Date -Format "yyyy-MM-dd") 
    }
    if ($val -as [double]) {
        try {
            return [datetime]::FromOADate($val).ToString("yyyy-MM-dd")
        } catch {
            return (Get-Date -Format "yyyy-MM-dd")
        }
    }
    return $val
}

# Load current state from the local API server
$stateUrl = "http://localhost:3000/api/state"
try {
    $state = Invoke-RestMethod -Uri $stateUrl -Method Get
    Write-Output "Successfully loaded current database state."
} catch {
    Write-Error "Failed to load current CRM database state."
    exit 1
}

# Open Excel workbook
$excel = New-Object -ComObject Excel.Application
$excel.Visible = $false
try {
    $workbook = $excel.Workbooks.Open($resolvedPath)
    $sheet = $workbook.Sheets.Item(1)
    $lastRow = $sheet.UsedRange.Rows.Count
    Write-Output "Found sheet '$($sheet.Name)' with $lastRow rows of data."
    
    $importedCount = 0
    $updatedCount = 0
    
    # Initialize leads array if null
    if ($null -eq $state.leads) {
        $state.leads = @()
    }
    
    for ($row = 2; $row -le $lastRow; $row++) {
        $contactDateVal = $sheet.Cells.Item($row, 1).Value2
        $name = $sheet.Cells.Item($row, 2).Value2
        $statusVal = $sheet.Cells.Item($row, 3).Value2
        $clientCode = $sheet.Cells.Item($row, 4).Value2
        $cskh = $sheet.Cells.Item($row, 5).Value2
        $phoneVal = $sheet.Cells.Item($row, 6).Value2
        $sourceVal = $sheet.Cells.Item($row, 7).Value2
        $noteVal = $sheet.Cells.Item($row, 9).Value2
        $failReasonVal = $sheet.Cells.Item($row, 12).Value2
        
        # Skip if name is empty
        if (-not $name) { continue }
        
        $name = "$name".Trim()
        $phone = if ($phoneVal) { "$phoneVal".Trim() } else { "" }
        
        # Source Mapping (normalized mapping to final display values)
        $mappedSourceCode = Get-Source "$sourceVal"
        $source = "Fanpage"
        if ($mappedSourceCode -eq "KH cu") { $source = "KH cu" }
        elseif ($mappedSourceCode -eq "BNI") { $source = "BNI" }
        elseif ($mappedSourceCode -eq "GT") { $source = "GT" }
        elseif ($mappedSourceCode -eq "Ca nhan") { $source = "Ca nhan" }
        elseif ($mappedSourceCode -eq "Gioi thieu") { $source = "Gioi thieu" }
        
        # Display accents in final array values
        if ($source -eq "KH cu") { $source = "KH cũ" }
        if ($source -eq "Ca nhan") { $source = "Cá nhân" }
        if ($source -eq "Gioi thieu") { $source = "Giới thiệu" }
        
        $salesId = Get-SalesId "$cskh"
        $stage = Get-Stage "$statusVal"
        $dateStr = Convert-ExcelDate $contactDateVal
        
        # Determine fail reason
        $failReason = $null
        if ($stage -eq "failed") {
            $failReason = "Khach hang ko quan tam"
            if ($failReasonVal) {
                $failReason = "$failReasonVal".Trim()
            }
        }
        if ($failReason -eq "Khach hang ko quan tam") {
            $failReason = "Khách hàng ko quan tâm"
        }
        
        # Build note
        $note = ""
        if ($clientCode) { $note += "[Ma KH: $clientCode] " }
        if ($noteVal) { $note += "$noteVal" }
        if ($note -match "Ma KH") {
            $note = $note -replace "Ma KH", "Mã KH"
        }
        
        # Format times
        $nowStr = (Get-Date -Format "yyyy-MM-dd HH:mm")
        
        # Search for existing lead to merge/update
        $existingLead = $null
        foreach ($l in $state.leads) {
            # Match by phone (if not empty) or name
            if (($phone -and $l.phone -eq $phone) -or ($l.name.ToLower().Trim() -eq $name.ToLower().Trim())) {
                $existingLead = $l
                break
            }
        }
        
        if ($null -ne $existingLead) {
            # Update fields
            $existingLead.stage = $stage
            if ($phone) { $existingLead.phone = $phone }
            $existingLead.source = $source
            $existingLead.salesId = $salesId
            $existingLead.note = $note
            $existingLead.failReason = $failReason
            $existingLead.updatedTime = $nowStr
            $updatedCount++
        } else {
            # Create new lead
            $newLead = @{
                id = "lead-excel-$row-$(Get-Random -Minimum 100 -Maximum 999)"
                name = $name
                phone = $phone
                source = $source
                valRmb = 0
                valVnd = 0
                note = $note
                salesId = $salesId
                stage = $stage
                failReason = $failReason
                date = $dateStr
                createdTime = "$dateStr 09:00"
                updatedTime = $nowStr
            }
            $state.leads += $newLead
            $importedCount++
        }
    }
    
    $workbook.Close($false)
    Write-Output "Finished parsing Excel data. New: $importedCount, Updated: $updatedCount."
    
    # Save the updated state to the local API server
    $jsonBody = ConvertTo-Json $state -Depth 10 -Compress
    $postResponse = Invoke-RestMethod -Uri $stateUrl -Method Post -Body $jsonBody -ContentType "application/json; charset=utf-8"
    Write-Output "Successfully synchronized state with the server database!"
    
} catch {
    Write-Error $_.Exception.Message
} finally {
    $excel.Quit()
    [System.Runtime.Interopservices.Marshal]::ReleaseComObject($excel) | Out-Null
}
